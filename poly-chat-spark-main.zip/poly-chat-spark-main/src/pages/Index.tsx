import { useState, useEffect } from "react";
import { MessageCircle, Globe, Zap, Shield, Clock, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChatInterface } from "@/components/ChatInterface";
import { ChatWidget } from "@/components/ChatWidget";
import { OnboardingModal } from "@/components/OnboardingModal";

export default function Index() {
  const [showChat, setShowChat] = useState(false);
  const [showWidget, setShowWidget] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState(false);

  useEffect(() => {
    // Check if user has completed onboarding
    const completed = localStorage.getItem('onboarding-completed');
    if (!completed) {
      setShowOnboarding(true);
    } else {
      setHasCompletedOnboarding(true);
    }
  }, []);

  const handleOnboardingComplete = () => {
    localStorage.setItem('onboarding-completed', 'true');
    setHasCompletedOnboarding(true);
  };

  const startChat = () => {
    if (!hasCompletedOnboarding) {
      setShowOnboarding(true);
    } else {
      setShowChat(true);
    }
  };

  const features = [
    {
      icon: Globe,
      title: "Multilingual Support",
      description: "Communicate in 8+ languages with real-time translation capabilities"
    },
    {
      icon: Zap,
      title: "Instant Responses",
      description: "Lightning-fast AI responses with dynamic conversation flow"
    },
    {
      icon: Shield,
      title: "Secure & Private",
      description: "Your conversations are encrypted and never stored permanently"
    },
    {
      icon: Clock,
      title: "24/7 Availability",
      description: "Always ready to help, any time of day or night"
    },
    {
      icon: Users,
      title: "Team Collaboration",
      description: "Share conversations and insights with your team members"
    },
    {
      icon: MessageCircle,
      title: "Smart Context",
      description: "Remembers conversation context for more meaningful interactions"
    }
  ];

  if (showChat) {
    return <ChatInterface />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-surface to-muted">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6 animate-fade-in">
            <Zap className="w-4 h-4" />
            <span>Powered by Advanced AI Technology</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent animate-fade-in">
            Multilingual AI Chatbot
            <br />
            <span className="bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              for Global Communication
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-10 animate-fade-in">
            Break language barriers with our intelligent chatbot that speaks your language. 
            Get instant responses, seamless translations, and natural conversations in over 8 languages.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Button 
              onClick={startChat}
              size="lg"
              className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary-hover hover:to-purple-700 text-white px-8 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Start Chatting Now
            </Button>
            
            <Button 
              onClick={() => setShowWidget(!showWidget)}
              variant="outline"
              size="lg"
              className="px-8 py-6 text-lg rounded-xl border-2 hover:bg-surface-hover transition-all duration-300"
            >
              <Globe className="w-5 h-5 mr-2" />
              Try Widget Mode
            </Button>
          </div>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-br from-primary/20 to-purple-600/20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-gradient-to-tr from-accent/20 to-primary/20 rounded-full blur-2xl"></div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why Choose Our AI Chatbot?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Experience the future of multilingual communication with cutting-edge AI technology
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index}
                className="group p-6 rounded-2xl bg-surface hover:bg-surface-hover border border-border hover:border-primary/20 shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/10 to-purple-600/10 flex items-center justify-center mb-4 group-hover:from-primary/20 group-hover:to-purple-600/20 transition-all duration-300">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                
                <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors duration-300">
                  {feature.title}
                </h3>
                
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/5 to-purple-600/5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Start Multilingual Conversations?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of users who trust our AI chatbot for seamless global communication
          </p>
          
          <Button 
            onClick={startChat}
            size="lg"
            className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary-hover hover:to-purple-700 text-white px-12 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            Launch Chatbot
          </Button>
        </div>
      </section>

      {/* Chat Widget */}
      {showWidget && <ChatWidget />}
      
      {/* Onboarding Modal */}
      <OnboardingModal 
        isOpen={showOnboarding}
        onClose={() => setShowOnboarding(false)}
        onComplete={() => {
          handleOnboardingComplete();
          setShowChat(true);
        }}
      />
    </div>
  );
}