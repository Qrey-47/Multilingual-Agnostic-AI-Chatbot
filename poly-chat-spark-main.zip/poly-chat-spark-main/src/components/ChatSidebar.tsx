import { useState } from "react";
import { Search, Plus, MessageCircle, Clock, Trash2, Archive, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDistanceToNow } from "date-fns";

interface ChatHistory {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  language: string;
  messageCount: number;
}

interface ChatSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNewChat: () => void;
  onSelectChat: (chatId: string) => void;
  currentChatId?: string;
}

const mockChatHistory: ChatHistory[] = [
  {
    id: "1",
    title: "Spanish Language Help",
    lastMessage: "¡Gracias por la ayuda con la gramática!",
    timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
    language: "es",
    messageCount: 12,
  },
  {
    id: "2", 
    title: "French Conversation Practice",
    lastMessage: "Au revoir! Merci beaucoup pour la conversation.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
    language: "fr",
    messageCount: 28,
  },
  {
    id: "3",
    title: "Business German Translation",
    lastMessage: "Die Übersetzung war sehr hilfreich.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    language: "de",
    messageCount: 8,
  },
  {
    id: "4",
    title: "Japanese Culture Questions",
    lastMessage: "Thank you for explaining Japanese customs!",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
    language: "ja",
    messageCount: 15,
  },
  {
    id: "5",
    title: "Italian Cooking Recipe",
    lastMessage: "La ricetta era perfetta! Grazie mille.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3), // 3 days ago
    language: "it",
    messageCount: 6,
  },
];

const languageFlags: Record<string, string> = {
  en: "🇺🇸",
  es: "🇪🇸", 
  fr: "🇫🇷",
  de: "🇩🇪",
  it: "🇮🇹",
  pt: "🇵🇹",
  zh: "🇨🇳",
  ja: "🇯🇵",
};

export function ChatSidebar({ isOpen, onClose, onNewChat, onSelectChat, currentChatId }: ChatSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredChats, setFilteredChats] = useState(mockChatHistory);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (!query.trim()) {
      setFilteredChats(mockChatHistory);
      return;
    }

    const filtered = mockChatHistory.filter(chat =>
      chat.title.toLowerCase().includes(query.toLowerCase()) ||
      chat.lastMessage.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredChats(filtered);
  };

  const handleNewChat = () => {
    onNewChat();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/20 z-40 md:hidden" 
        onClick={onClose}
      />
      
      {/* Sidebar */}
      <div className={`
        fixed left-0 top-0 h-full w-80 bg-surface shadow-2xl z-50 transform transition-transform duration-300
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:relative md:translate-x-0
      `}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-primary/5 to-purple-600/5">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-primary" />
            <h2 className="font-semibold text-lg">Chat History</h2>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose} className="md:hidden">
            <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>

        {/* New Chat Button */}
        <div className="p-4 border-b">
          <Button 
            onClick={handleNewChat}
            className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary-hover hover:to-purple-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Chat
          </Button>
        </div>

        {/* Search */}
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10 pr-4"
            />
          </div>
        </div>

        {/* Chat List */}
        <ScrollArea className="flex-1 p-2">
          <div className="space-y-2">
            {filteredChats.map((chat) => (
              <div
                key={chat.id}
                onClick={() => onSelectChat(chat.id)}
                className={`
                  group relative p-3 rounded-lg cursor-pointer transition-all duration-200 hover:bg-surface
                  ${currentChatId === chat.id ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted/50'}
                `}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs">{languageFlags[chat.language]}</span>
                      <h3 className="font-medium text-sm truncate">
                        {chat.title}
                      </h3>
                    </div>
                    
                    <p className="text-xs text-muted-foreground truncate mb-2">
                      {chat.lastMessage}
                    </p>
                    
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      <span>{formatDistanceToNow(chat.timestamp, { addSuffix: true })}</span>
                      <span>•</span>
                      <span>{chat.messageCount} msgs</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex gap-1 ml-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="w-6 h-6 p-0 hover:bg-muted"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle archive
                      }}
                    >
                      <Archive className="w-3 h-3" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="w-6 h-6 p-0 hover:bg-error/10 hover:text-error"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle delete
                      }}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredChats.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No conversations found</p>
            </div>
          )}
        </ScrollArea>
      </div>
    </>
  );
}