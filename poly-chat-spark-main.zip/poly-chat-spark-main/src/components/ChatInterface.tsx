import { useState, useRef, useEffect } from "react";
import { Send, MessageCircle, Globe, Menu, Plus, Paperclip, Image, ArrowLeft, Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MessageBubble } from "./MessageBubble";
import { TypingIndicator } from "./TypingIndicator";
import { VoiceMode } from "./VoiceMode";
import { ChatSidebar } from "./ChatSidebar";

interface Message {
  id: string;
  content: string;
  sender: "user" | "bot";
  timestamp: Date;
  language?: string;
}

const languages = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "mr", name: "मराठी", flag: "🇮🇳" },
  { code: "hi", name: "हिंदी", flag: "🇮🇳" },
  { code: "te", name: "తెలుగు", flag: "🇮🇳" },
  { code: "ml", name: "മലയാളം", flag: "🇮🇳" },
];

const botResponses = {
  en: [
    "Hello! How can I help you today?",
    "That's a great question! Let me help you with that.",
    "I understand. Here's what I can suggest...",
    "Is there anything else I can assist you with?",
  ],
  mr: [
    "नमस्कार! आज मी तुम्हाला कशी मदत करू शकतो?",
    "हा एक चांगला प्रश्न आहे! मी त्यात तुम्हाला मदत करतो.",
    "मला समजले. मी हे सुचवू शकतो...",
    "मी तुम्हाला आणखी काही मदत करू शकतो का?",
  ],
  hi: [
    "नमस्ते! आज मैं आपकी कैसे मदद कर सकता हूँ?",
    "यह एक बेहतरीन सवाल है! मैं इसमें आपकी मदद करता हूँ।",
    "मैं समझ गया। मैं यह सुझा सकता हूँ...",
    "क्या मैं आपकी और किसी चीज़ में मदद कर सकता हूँ?",
  ],
  te: [
    "నమస్కారం! ఈరోజు నేను మీకు ఎలా సహాయం చేయగలను?",
    "ఇది చాలా మంచి ప్రశ్న! నేను దీనిలో మీకు సహాయం చేస్తాను.",
    "నేను అర్థం చేసుకున్నాను. నేను ఇది సూచించగలను...",
    "నేను మీకు మరేదైనా సహాయం చేయగలనా?",
  ],
  ml: [
    "നമസ്കാരം! ഇന്ന് എനിക്ക് നിങ്ങളെ എങ്ങനെ സഹായിക്കാം?",
    "അത് നല്ലൊരു ചോദ്യമാണ്! ഞാൻ അതിൽ നിങ്ങളെ സഹായിക്കാം.",
    "ഞാൻ മനസ്സിലാക്കി. ഞാൻ ഇത് നിർദ്ദേശിക്കാം...",
    "ഞാൻ നിങ്ങളെ മറ്റെന്തെങ്കിലും സഹായിക്കാമോ?",
  ],
};

interface ChatInterfaceProps {
  onShowSidebar?: () => void;
  showSidebar?: boolean;
  onNewChat?: () => void;
}

export function ChatInterface({ onShowSidebar, showSidebar, onNewChat }: ChatInterfaceProps = {}) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Hello! I'm your multilingual assistant. How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("en");
  const [isTyping, setIsTyping] = useState(false);
  const [voiceModeActive, setVoiceModeActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showFileOptions, setShowFileOptions] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { theme, setTheme } = useTheme();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateBotResponse = (userMessage: string, language: string) => {
    const responses = botResponses[language as keyof typeof botResponses] || botResponses.en;
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: "user",
      timestamp: new Date(),
      language: selectedLanguage,
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    // Simulate bot typing delay
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: generateBotResponse(inputValue, selectedLanguage),
        sender: "bot",
        timestamp: new Date(),
        language: selectedLanguage,
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleVoiceInput = (text: string) => {
    setInputValue(text);
    // Auto-send voice input after a brief delay
    setTimeout(() => {
      if (text.trim()) {
        handleSendMessage();
      }
    }, 500);
  };

  const handleNewChat = () => {
    setMessages([
      {
        id: Date.now().toString(),
        content: "Hello! I'm your multilingual assistant. How can I help you today?",
        sender: "bot",
        timestamp: new Date(),
      },
    ]);
    setInputValue("");
    setIsTyping(false);
    onNewChat?.();
  };

  const handleSelectChat = (chatId: string) => {
    // In a real app, load chat history from storage/API
    console.log("Loading chat:", chatId);
    setSidebarOpen(false);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      // Handle file upload logic here
      console.log("Files selected:", files);
      setShowFileOptions(false);
    }
  };

  const handleBack = () => {
    // Navigate to home or previous page
    window.location.href = '/';
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Chat Sidebar */}
      <ChatSidebar 
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onNewChat={handleNewChat}
        onSelectChat={handleSelectChat}
      />

      {/* Main Chat Area */}
      <div className="flex flex-col flex-1 max-w-4xl mx-auto bg-background">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-surface shadow-sm">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="text-muted-foreground hover:text-primary"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(true)}
              className="text-muted-foreground hover:text-primary"
            >
              <Menu className="w-5 h-5" />
            </Button>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-semibold">AI Assistant</h1>
              <p className="text-sm text-muted-foreground">Online • Ready to help</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="text-muted-foreground hover:text-primary"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleNewChat}
              className="text-muted-foreground hover:text-primary"
            >
              <Plus className="w-4 h-4" />
            </Button>
            <Globe className="w-4 h-4 text-muted-foreground" />
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-36 h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <span className="flex items-center gap-2">
                      <span>{lang.flag}</span>
                      {lang.name}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Messages Container */}
        <div className="flex-1 overflow-y-auto p-4 chat-background custom-scrollbar">
          <div className="space-y-4 max-w-3xl mx-auto">
            {/* Voice Mode Component */}
            <VoiceMode 
              isActive={voiceModeActive}
              onToggle={() => setVoiceModeActive(!voiceModeActive)}
              onVoiceInput={handleVoiceInput}
              isMuted={isMuted}
              onMuteToggle={() => setIsMuted(!isMuted)}
            />
            
            {messages.map((message) => (
              <MessageBubble
                key={message.id}
                message={message}
                isOwn={message.sender === "user"}
              />
            ))}
            {isTyping && <TypingIndicator />}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input Area */}
        <div className="p-4 border-t bg-surface">
          <div className="flex items-end gap-2 max-w-3xl mx-auto">
            {/* File Upload Options */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowFileOptions(!showFileOptions)}
                className="text-muted-foreground hover:text-primary p-2"
              >
                <Paperclip className="w-5 h-5" />
              </Button>
              
              {showFileOptions && (
                <div className="absolute bottom-full left-0 mb-2 bg-surface border rounded-lg shadow-lg p-2 space-y-1 animate-fade-in">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full justify-start text-sm"
                  >
                    <Paperclip className="w-4 h-4 mr-2" />
                    Add File
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full justify-start text-sm"
                  >
                    <Image className="w-4 h-4 mr-2" />
                    Add Image
                  </Button>
                </div>
              )}
              
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                accept="image/*,*"
                multiple
              />
            </div>
            
            <div className="flex-1 relative">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={`Type your message in ${languages.find(l => l.code === selectedLanguage)?.name}...`}
                className="py-3 resize-none rounded-xl border-2 focus:border-primary/50"
                disabled={voiceModeActive}
              />
            </div>
            
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || voiceModeActive}
              className="w-12 h-12 rounded-xl bg-gradient-to-r from-primary to-purple-600 hover:from-primary-hover hover:to-purple-700 transition-all duration-200"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}