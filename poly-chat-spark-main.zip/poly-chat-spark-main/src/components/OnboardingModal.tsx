import { useState, useEffect } from "react";
import { X, ArrowRight, MessageCircle, Globe, Mic, Search, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

const onboardingSteps = [
  {
    id: 1,
    title: "Welcome to AI Assistant!",
    description: "Your multilingual conversation companion is ready to help you communicate in 8+ languages.",
    icon: MessageCircle,
    highlight: "Start chatting in any language",
  },
  {
    id: 2,
    title: "Speak Your Language",
    description: "Switch between languages instantly. Our AI understands context and maintains conversation flow.",
    icon: Globe,
    highlight: "Try the language selector",
  },
  {
    id: 3,
    title: "Voice Conversations",
    description: "Talk naturally with voice input and get audio responses. Perfect for hands-free communication.",
    icon: Mic,
    highlight: "Use voice mode for natural talks",
  },
  {
    id: 4,
    title: "Chat History & Search",
    description: "Access all your conversations and search through them easily. Never lose important information.",
    icon: Search,
    highlight: "Find any conversation instantly",
  },
  {
    id: 5,
    title: "Ready to Start!",
    description: "You're all set! Create new chats, explore different languages, and enjoy seamless AI conversations.",
    icon: Plus,
    highlight: "Let's begin your journey",
  },
];

export function OnboardingModal({ isOpen, onClose, onComplete }: OnboardingModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setCurrentStep(0);
    }
  }, [isOpen]);

  const handleNext = () => {
    if (currentStep < onboardingSteps.length - 1) {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentStep(currentStep + 1);
        setIsAnimating(false);
      }, 200);
    } else {
      onComplete();
      onClose();
    }
  };

  const handleSkip = () => {
    onComplete();
    onClose();
  };

  if (!isOpen) return null;

  const currentStepData = onboardingSteps[currentStep];
  const IconComponent = currentStepData.icon;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 animate-fade-in">
      <Card className={`w-full max-w-md bg-surface shadow-2xl transition-all duration-300 ${isAnimating ? 'scale-95 opacity-80' : 'scale-100 opacity-100'}`}>
        <CardContent className="p-0">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b">
            <div className="flex items-center gap-2">
              <div className="flex space-x-1">
                {onboardingSteps.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      index <= currentStep ? 'bg-primary' : 'bg-muted'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-muted-foreground ml-2">
                {currentStep + 1} of {onboardingSteps.length}
              </span>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Content */}
          <div className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary/20 to-purple-600/20 flex items-center justify-center animate-scale-in">
              <IconComponent className="w-8 h-8 text-primary" />
            </div>

            <h2 className="text-2xl font-bold mb-4 animate-fade-in">
              {currentStepData.title}
            </h2>

            <p className="text-muted-foreground mb-6 leading-relaxed animate-fade-in">
              {currentStepData.description}
            </p>

            <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 mb-8 animate-slide-up">
              <p className="text-sm font-medium text-primary">
                💡 {currentStepData.highlight}
              </p>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-6 border-t bg-surface">
            <Button variant="ghost" onClick={handleSkip}>
              Skip Tour
            </Button>
            
            <Button onClick={handleNext} className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary-hover hover:to-purple-700">
              {currentStep === onboardingSteps.length - 1 ? 'Get Started' : 'Next'}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}