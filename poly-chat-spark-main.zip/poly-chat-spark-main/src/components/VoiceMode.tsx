import { useState, useEffect } from "react";
import { Mic, MicOff, Volume2, VolumeX, Waves, Speaker } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface VoiceModeProps {
  isActive: boolean;
  onToggle: () => void;
  onVoiceInput: (text: string) => void;
  isMuted: boolean;
  onMuteToggle: () => void;
}

export function VoiceMode({ isActive, onToggle, onVoiceInput, isMuted, onMuteToggle }: VoiceModeProps) {
  const [isListening, setIsListening] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const [transcript, setTranscript] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Simulate voice recognition (in a real app, you'd use Web Speech API)
  useEffect(() => {
    if (isListening) {
      const interval = setInterval(() => {
        setAudioLevel(Math.random() * 100);
      }, 100);

      // Simulate voice input after 3 seconds
      const timeout = setTimeout(() => {
        const sampleTexts = [
          "Hello, how are you today?",
          "Can you help me translate this to Spanish?",
          "What's the weather like?",
          "Tell me a joke in French",
        ];
        const randomText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
        setTranscript(randomText);
        onVoiceInput(randomText);
        setIsListening(false);
        setAudioLevel(0);
        
        // Simulate voice response
        if (!isMuted) {
          setIsSpeaking(true);
          setTimeout(() => setIsSpeaking(false), 2000);
        }
      }, 3000);

      return () => {
        clearInterval(interval);
        clearTimeout(timeout);
      };
    } else {
      setAudioLevel(0);
      setTranscript("");
    }
  }, [isListening, onVoiceInput]);

  const handleVoiceToggle = () => {
    if (isActive) {
      setIsListening(!isListening);
    } else {
      onToggle();
    }
  };

  if (!isActive) {
    return (
      <Button
        variant="ghost"
        size="sm"
        onClick={onToggle}
        className="text-muted-foreground hover:text-primary"
      >
        <Mic className="w-4 h-4" />
      </Button>
    );
  }

  return (
    <Card className="mb-4 border-2 border-primary/20 bg-gradient-to-r from-primary/5 to-purple-600/5">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-sm font-medium">Voice Mode Active</span>
          </div>
          <Button variant="ghost" size="sm" onClick={onToggle}>
            <Waves className="w-4 h-4" />
          </Button>
        </div>

        {/* Audio Visualizer */}
        <div className="flex items-center justify-center gap-1 mb-4 h-12">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className={`w-1 bg-primary rounded-full transition-all duration-150 ${
                isListening ? 'animate-pulse' : ''
              }`}
              style={{ 
                height: isListening 
                  ? `${Math.max(8, (audioLevel + Math.random() * 20))}px` 
                  : '8px',
                animationDelay: `${i * 50}ms`
              }}
            />
          ))}
        </div>

        {/* Transcript */}
        {transcript && (
          <div className="bg-surface/50 rounded-lg p-3 mb-4 animate-fade-in">
            <p className="text-sm text-muted-foreground mb-1">You said:</p>
            <p className="text-sm font-medium">{transcript}</p>
          </div>
        )}

        {/* Controls */}
        <div className="flex items-center justify-center gap-4">
          <Button
            variant={isListening ? "destructive" : "default"}
            size="lg"
            onClick={handleVoiceToggle}
            className={`rounded-full w-16 h-16 ${
              isListening 
                ? 'bg-error hover:bg-error/90' 
                : 'bg-primary hover:bg-primary-hover'
            }`}
          >
            {isListening ? (
              <MicOff className="w-6 h-6" />
            ) : (
              <Mic className="w-6 h-6" />
            )}
          </Button>

          <Button
            variant="outline"
            size="lg"
            className={`rounded-full w-16 h-16 ${
              isSpeaking 
                ? 'bg-primary/10 border-primary animate-pulse' 
                : 'border-border'
            }`}
            disabled
          >
            <Speaker className={`w-6 h-6 ${isSpeaking ? 'text-primary' : 'text-muted-foreground'}`} />
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={onMuteToggle}
            className={isMuted ? 'text-error' : ''}
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </Button>
        </div>

        <p className="text-xs text-center text-muted-foreground mt-3">
          {isListening ? 'Listening... Speak now' : 'Click microphone to start speaking'}
        </p>
      </CardContent>
    </Card>
  );
}