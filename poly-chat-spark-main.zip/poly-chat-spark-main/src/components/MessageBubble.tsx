import { format } from "date-fns";

interface Message {
  id: string;
  content: string;
  sender: "user" | "bot";
  timestamp: Date;
  language?: string;
}

interface MessageBubbleProps {
  message: Message;
  isOwn: boolean;
}

export function MessageBubble({ message, isOwn }: MessageBubbleProps) {
  return (
    <div className={`flex ${isOwn ? "justify-end" : "justify-start"} animate-message-in`}>
      <div className={`flex items-end gap-2 max-w-xs md:max-w-md lg:max-w-lg ${isOwn ? "flex-row-reverse" : "flex-row"}`}>
        {/* Avatar */}
        {!isOwn && (
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center flex-shrink-0">
            <span className="text-xs font-medium text-primary-foreground">AI</span>
          </div>
        )}
        
        {/* Message Content */}
        <div className={`px-4 py-3 ${isOwn ? "message-bubble-user" : "message-bubble-bot"}`}>
          <p className="text-sm leading-relaxed">
            {message.content}
          </p>
          
          {/* Timestamp */}
          <div className={`text-xs mt-1 ${isOwn ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
            {format(message.timestamp, "HH:mm")}
          </div>
        </div>
        
        {/* User Avatar */}
        {isOwn && (
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent to-green-500 flex items-center justify-center flex-shrink-0">
            <span className="text-xs font-medium text-accent-foreground">ME</span>
          </div>
        )}
      </div>
    </div>
  );
}