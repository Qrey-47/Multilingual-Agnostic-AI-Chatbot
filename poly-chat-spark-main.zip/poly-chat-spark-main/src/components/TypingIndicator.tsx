export function TypingIndicator() {
  return (
    <div className="flex justify-start animate-fade-in">
      <div className="flex items-end gap-2 max-w-xs">
        {/* Bot Avatar */}
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center flex-shrink-0">
          <span className="text-xs font-medium text-primary-foreground">AI</span>
        </div>
        
        {/* Typing Animation */}
        <div className="message-bubble-bot px-4 py-3">
          <div className="flex items-center gap-1">
            <div className="flex gap-1">
              <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-typing" style={{ animationDelay: '0ms' }}></div>
              <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-typing" style={{ animationDelay: '150ms' }}></div>
              <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-typing" style={{ animationDelay: '300ms' }}></div>
            </div>
            <span className="text-xs text-muted-foreground ml-2">AI is typing...</span>
          </div>
        </div>
      </div>
    </div>
  );
}